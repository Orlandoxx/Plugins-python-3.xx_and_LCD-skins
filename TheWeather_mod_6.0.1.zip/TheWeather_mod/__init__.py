#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright (c) @speedy2026
# modified by Orlandox 27.09.2026

from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Components.Language import language
from Screens.MessageBox import MessageBox

from os.path import exists, join, dirname
from enigma import getDesktop, gRGB, quitMainloop
from skin import parseColor

from os import makedirs, environ, rmdir, walk, remove

import gettext
import codecs
import shutil
import urllib.request
import subprocess
import os

# ============================================================================
# VERSION / AUTHOR
# ============================================================================

__version__ = "6.0.0"
VERSION = __version__

_AUTHOR_ = "by speedy005 - 2026"
IDEAS = "@speedy005"
THANKS = "@speedy005 | @Caught"

# ============================================================================
# PATHS
# ============================================================================

TEMP_DIR = "/tmp/TheWeather_mod"
SYSTEM_DIR = "/etc/enigma2/TheWeather_mod"

PLUGIN_PATH = dirname(__file__)

# ============================================================================
# DEBUG / CACHE
# ============================================================================

DEBUG = False
CACHE_EXPIRE = 3600

# ============================================================================
# CREATE REQUIRED DIRECTORIES
# ============================================================================

if not exists(SYSTEM_DIR):
    makedirs(
        SYSTEM_DIR
    )
if not exists(TEMP_DIR):
    makedirs(
        TEMP_DIR
    )

# ============================================================================
# LANGUAGE
# ============================================================================

PluginLanguageDomain = "TheWeather_mod"

PluginLanguagePath = (
    "Extensions/TheWeather_mod/locale"
)

def localeInit():
    lang = language.getLanguage()[:2]
    environ["LANGUAGE"] = lang
    if PluginLanguageDomain and PluginLanguagePath:
        gettext.bindtextdomain(
            PluginLanguageDomain,
            resolveFilename(
                SCOPE_PLUGINS,
                PluginLanguagePath
            ),
        )

def _(txt):
    if not txt:
        return ""
    translated = gettext.dgettext(
        PluginLanguageDomain,
        txt
    )
    if translated and translated != txt:
        return translated
    print(
        "[%s] fallback to default translation for %s"
        % (
            PluginLanguageDomain,
            txt
        )
    )
    return gettext.gettext(txt)
localeInit()
language.addCallback(
    localeInit
)

# ============================================================================
# HTTP HEADERS
# ============================================================================

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/134.0.0.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,"
        "application/xml;q=0.9,*/*;q=0.8"
    ),
    "Accept-Language": (
        "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7"
    ),
    "Connection": "keep-alive",
}

OSM_HEADERS = {
    "User-Agent": (
        "TheWeather_mod/1.1.1 "
        "(Enigma2; OpenStreetMap; non-commercial; "
        "+https://github.com/speedy005/TheWeather_mod)"
    ),
    "Referer": "https://www.foreca.com",
    "Accept": (
        "image/webp,image/png,image/*;q=0.8"
    ),
    "Accept-Language": (
        "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7"
    ),
    "Connection": "keep-alive",
}

# ============================================================================
# SCREEN RESOLUTION
# ============================================================================

def get_screen_resolution():
    desktop = getDesktop(0)
    return desktop.size()

def get_resolution_type():
    width = get_screen_resolution().width()
    if width >= 2560:
        return "wqhd"
    elif width >= 1920:
        return "fhd"
    else:
        return "hd"

# ============================================================================
# GLOBAL THEME
# ============================================================================

def apply_global_theme(screen):
    color_file = join(
        SYSTEM_DIR,
        "set_color.conf"
    )
    alpha_file = join(
        SYSTEM_DIR,
        "set_alpha.conf"
    )

    # ------------------------------------------------------------------------
    # Background color
    # ------------------------------------------------------------------------

    if exists(color_file):
        try:
            with open(
                color_file,
                "r"
            ) as f:
                parts = (
                    f.read()
                    .strip()
                    .split()
                )
                if len(parts) >= 3:
                    r = parts[0]
                    g = parts[1]
                    b = parts[2]
                    bg_color = gRGB(
                        int(r),
                        int(g),
                        int(b)
                    )
                    if "background_plate" in screen:
                        screen[
                            "background_plate"
                        ].instance.setBackgroundColor(
                            bg_color
                        )
        except Exception as e:
            print(
                "[Theme] Error loading color:",
                e
            )

    # ------------------------------------------------------------------------
    # Transparency
    # ------------------------------------------------------------------------

    if exists(alpha_file):
        try:
            with open(
                alpha_file,
                "r"
            ) as f:
                alpha = f.read().strip()
                if "selection_overlay" in screen:
                    screen[
                        "selection_overlay"
                    ].instance.setBackgroundColor(
                        parseColor(alpha)
                    )
        except Exception as e:
            print(
                "[Theme] Error loading alpha:",
                e
            )

# ============================================================================
# CLEANUP TEMP FILES
# ============================================================================

def cleanup_temp_files(keep_token=True):
    d = TEMP_DIR
    if not exists(d):
        return
    try:
        # --------------------------------------------------------------------
        # Keep token.json
        # --------------------------------------------------------------------
        if keep_token:
            token_path = join(
                TEMP_DIR,
                "weather_map_cache",
                "token.json"
            )
            for root, dirs, files in walk(
                d,
                topdown=False
            ):
                # ------------------------------------------------------------
                # Files
                # ------------------------------------------------------------
                for name in files:
                    file_path = join(
                        root,
                        name
                    )
                    if file_path != token_path:
                        remove(
                            file_path
                        )

                # ------------------------------------------------------------
                # Directories
                # ------------------------------------------------------------
                for name in dirs:
                    dir_path = join(
                        root,
                        name
                    )
                    if (
                        dir_path
                        == join(
                            TEMP_DIR,
                            "weather_map_cache"
                        )
                    ):
                        continue
                    try:
                        rmdir(
                            dir_path
                        )
                    except OSError:
                        pass

            # ----------------------------------------------------------------
            # Recreate required TEMP directories
            # ----------------------------------------------------------------
            subdirs = [
                "meteogram",
                "weather_detail",
                "weather_map_cache/wetterkontor"
            ]
            for sub in subdirs:
                subdir = join(
                    TEMP_DIR,
                    sub
                )
                if not exists(subdir):
                    makedirs(
                        subdir
                    )
            if DEBUG:
                print(
                    "[Cleanup] Cleaned %s "
                    "(kept token)"
                    % TEMP_DIR
                )

        # --------------------------------------------------------------------
        # Complete remove
        # --------------------------------------------------------------------
        else:
            shutil.rmtree(
                TEMP_DIR
            )
            makedirs(
                TEMP_DIR
            )
            for sub in [
                "meteogram",
                "weather_detail",
                "weather_map_cache/wetterkontor"
            ]:
                subdir = join(
                    TEMP_DIR,
                    sub
                )
                if not exists(subdir):
                    makedirs(
                        subdir
                    )
            if DEBUG:
                print(
                    "[Cleanup] Removed and recreated %s"
                    % TEMP_DIR
                )
    except Exception as e:
        print(
            "[Cleanup] Error cleaning %s: %s"
            % (
                TEMP_DIR,
                e
            )
        )

