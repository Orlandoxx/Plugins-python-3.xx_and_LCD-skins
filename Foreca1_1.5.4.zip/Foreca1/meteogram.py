#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright (c) @Lululla 2026
# meteogram.py - Custom meteogram for Foreca One


import datetime
from json import loads, JSONDecodeError
from os.path import exists, join
from os import makedirs, listdir, remove
import requests

from enigma import getDesktop, ePoint

from Screens.Screen import Screen
from Screens.HelpMenu import HelpableScreen
from Screens.ChoiceBox import ChoiceBox

from Components.ActionMap import HelpableActionMap
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigSelection, configfile


from . import (
    _,
    DEBUG,
    load_skin_for_class,
    apply_global_theme,
    PLUGIN_PATH,
    TEMP_DIR,
    DBG_DIR,
    HEADERS,
    get_icon_path
)
from .google_translate import (
    _get_system_language,
    translate_batch_strings,
    trans,
    translate_location
)

config.plugins.foreca1 = ConfigSubsection()
config.plugins.foreca1.meteogram_step = ConfigSelection(
    default="6",
    choices=[
        ("1", _("1 hour")),
        ("3", _("3 hours")),
        ("6", _("6 hours")),
    ]
)

METEOGRAM_DIR = join(TEMP_DIR, "meteogram")
if not exists(METEOGRAM_DIR):
    makedirs(METEOGRAM_DIR)


# =============================================================================
# SCREEN RESOLUTION DEPENDENT CONSTANTS
# =============================================================================
desk = getDesktop(0)
res = (desk.size().width(), desk.size().height())

if res == (1920, 1080):     # Full HD
    GRAPH_WIDTH = 1665
    GRAPH_HEIGHT = 522
    HOUR_STEP = 48
    GRAPH_TOP = 198
elif res == (1280, 720):    # HD ready
    GRAPH_WIDTH = 1105
    GRAPH_HEIGHT = 348
    HOUR_STEP = 32
    GRAPH_TOP = 132
elif res == (2560, 1440):   # WQHD
    GRAPH_WIDTH = 2215
    GRAPH_HEIGHT = 696
    HOUR_STEP = 64
    GRAPH_TOP = 264
else:                       # fallback (should match skin defaults)
    GRAPH_WIDTH = 1665
    GRAPH_HEIGHT = 522
    HOUR_STEP = 48
    GRAPH_TOP = 198

PERIODS = 35


def get_color_from_celsius(c):
    if c <= -20:
        return "#3b62ff"   # deep blue (very cold)
    elif c <= -15:
        return "#408cff"   # blue (cold)
    elif c <= -10:
        return "#40b3ff"   # medium blue (cold)
    elif c <= -5:
        return "#40d9ff"   # light blue (chilly)
    elif c <= 0:
        return "#40ffff"   # cyan (near freezing)
    elif c < 5:
        return "#53c905"   # dark green (cool)
    elif c < 10:
        return "#77f424"   # green (mild)
    elif c < 15:
        return "#ffff40"   # yellow (pleasant)
    elif c < 20:
        return "#ffb340"   # orange (warm)
    elif c < 25:
        return "#ff6640"   # red-orange (hot)
    elif c < 30:
        return "#ff4040"   # red (very hot)
    else:
        return "#ff40b3"   # magenta (extremely hot)


def write_meteogram_debug(text):
    try:
        dbg_path = join(DBG_DIR, "meteogram_debug.txt")
        with open(dbg_path, "a") as dbg:
            dbg.write(text + "\n")
    except Exception as e:
        print(f"[Meteogram] Debug write error: {e}")


def smooth_curve_path(nodes, k=3):
    if len(nodes) < 2:
        return ''

    def _lim(n):
        return max(0, min(len(nodes) - 1, n))

    mul = k / 20.0
    out = [f'M{nodes[0][0]},{nodes[0][1]}']

    for n in range(len(nodes) - 1):
        pA = nodes[_lim(n - 1)]
        pB = nodes[n]
        pC = nodes[n + 1]
        pD = nodes[_lim(n + 2)]

        bx1 = pB[0] + (pC[0] - pA[0]) * mul
        by1 = pB[1] + (pC[1] - pA[1]) * mul
        bx2 = pC[0] - (pD[0] - pB[0]) * mul
        by2 = pC[1] - (pD[1] - pB[1]) * mul

        out.append(f'C{bx1},{by1} {bx2},{by2} {pC[0]},{pC[1]}')

    return ' '.join(out)


def wind_arrow(degrees):
    """Convert wind direction in degrees to a cardinal letter (N, NE, …)."""
    try:
        deg = int(degrees) % 360
        directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
        return directions[round(deg / 45) % 8]
    except BaseException:
        return 'N'


def _translate_place(town, country):
    town_ctx = f"city name (proper noun): {town}"
    country_translated = trans(country + ":").replace(":", "").strip() if country else ""
    town_translated = translate_batch_strings([town_ctx])[0]
    town_translated = town_translated.split(": ", 1)[-1]

    if country_translated:
        return f"{town_translated}, {country_translated}"
    else:
        return town_translated


class MeteogramView(Screen, HelpableScreen):
    """
    Screen that displays a 7-day meteogram with temperature curve,
    precipitation bars, weather icons, wind information and date markers.
    All widget names are unique to this plugin.
    """

    def __init__(
            self,
            session,
            weather_api,
            location_id,
            location_name,
            unit_manager=None,
            tz=None,
            tz_offset=None):
        self.skin = load_skin_for_class(MeteogramView)
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.setTitle(_("Meteogram"))

        self.api = weather_api
        self.loc_id = location_id
        self.loc_name = location_name
        self.units = unit_manager
        self.tz = tz
        self.tz_offset = tz_offset

        if not exists(METEOGRAM_DIR):
            makedirs(METEOGRAM_DIR)

        self["background_plate"] = Label("")
        self["selection_overlay"] = Label("")

        # --- Main widgets (custom names) ---
        self["temp_curve"] = Pixmap()                  # SVG temperature line
        self["update_label"] = Label()                 # last update time
        self["wind_unit_label"] = Label()              # wind speed unit (km/h or mph)
        self["city_label"] = Label()                   # city name
        self["zero_line"] = Pixmap()                   # 0°C indicator (PNG)
        self["key_menu"] = Label(_("MENU - Settings")) # MENU button label

        self["precip_text"] = Label(_("Precipitations"))
        self["showers_text"] = Label(_("Showers"))

        # --- 35 periods ---
        for i in range(PERIODS):
            self[f"time_{i}"] = Label(" ")          # hour (e.g. "12")
            self[f"weather_{i}"] = Pixmap()         # weather icon
            self[f"winddir_{i}"] = Pixmap()         # wind direction icon
            self[f"rainbar_{i}"] = Pixmap()         # precipitation bar (SVG)
            self[f"windspeed_{i}"] = Label(" ")     # wind speed value

        # --- Temperature and rain scales (8 levels) ---
        for i in range(8):
            self[f"temp_scale_{i}"] = Label("  ")
            self[f"rain_scale_{i}"] = Label("")

        # --- Date separators (up to 10 days) ---
        for i in range(9):
            self[f"date_{i}"] = Label(" ")
            self[f"vline_{i}"] = Pixmap()           # vertical separator line

        self["vline_9"] = Pixmap()
        self["actions"] = HelpableActionMap(
            self, "ForecaActions",
            {
                "cancel": (self.close, _("Close")),
                "red": (self.close, _("Close")),
                "ok": (self.close, _("Close")),
                "menu": (self.open_settings_menu, _("Settings")),
            },
            -1
        )
        self.onLayoutFinish.append(self.fetch_data)
        self.onClose.append(self.cleanup_temp_files)
        self.onLayoutFinish.append(self._apply_theme)

    def _apply_theme(self):
        apply_global_theme(self)

    def cleanup_temp_files(self):
        if exists(METEOGRAM_DIR):
            try:
                for f in listdir(METEOGRAM_DIR):
                    if f.startswith(
                            'foreca_temp_curve.svg') or f.startswith('rainbar_'):
                        file_path = join(METEOGRAM_DIR, f)
                        remove(file_path)
                if DEBUG:
                    print(
                        f"[Meteogram] Cleaned temporary SVG files from {METEOGRAM_DIR}")
            except Exception as e:
                print(f"[Meteogram] Error cleaning temp files: {e}")

    def fetch_data(self):
        """Download the detailed forecast page and extract JSON data."""
        lang = _get_system_language()
        place = self.api.get_location_by_id(self.loc_id)
        if not place:
            self.close()
            return

        url = f"https://www.foreca.com/{lang}/{self.loc_id}/{place.address}/detailed-forecast"
        try:
            resp = requests.get(url, headers=HEADERS, timeout=15)
            if resp.status_code != 200:
                return
            html = resp.text
        except Exception as e:
            print(f"[Meteogram] Network error: {e}")
            return

        # Extract JSON block from the HTML
        start = html.find('ranges: {')
        if start == -1:
            return
        json_str = html[start:].replace('ranges', '{ "ranges"')
        json_str = json_str.replace('data3h', '"3h"').replace('data', '"data"')
        end = json_str.find('showDetails:')
        if end == -1:
            return
        json_str = json_str[:end - 10] + '}'

        try:
            data = loads(json_str)
        except JSONDecodeError as e:
            print(f"[Meteogram] JSON error: {e}")
            return

        forecast = data.get('data', [])
        ranges = data.get('ranges', {})

        if not forecast or not ranges:
            return

        # Update time (first element's 'updated' field)
        if forecast and len(forecast) > 1:
            updated_utc = forecast[1].get('updated', '').replace('Z', '+00:00')
            try:
                dt_utc = datetime.datetime.fromisoformat(updated_utc)
                if self.tz:
                    dt_local = dt_utc.astimezone(self.tz)
                elif self.tz_offset is not None:
                    dt_local = dt_utc +                         datetime.timedelta(hours=self.tz_offset)
                else:
                    dt_local = dt_utc
                self["update_label"].setText(
                    _("Updated: {}").format(
                        dt_local.strftime('%d.%m.%y %H:%M')))
            except BaseException:
                pass

        # Select time step (1h, 3h, or default 6h)
        step = int(config.plugins.foreca1.meteogram_step.value)

        if step in (1, 3) and hasattr(self.api, 'get_hourly_forecast'):
            hourly_list = []
            days_to_fetch = 2 if step == 1 else 5
            base_date = datetime.date.today()

            for d in range(days_to_fetch):
                try:
                    day_hours = self.api.get_hourly_forecast(self.loc_id, day=d)
                    if not day_hours:
                        continue
                    cur_date = base_date + datetime.timedelta(days=d)
                    for h in day_hours:
                        if isinstance(h.time, datetime.datetime):
                            dt_obj = h.time
                        else:
                            dt_obj = datetime.datetime.combine(cur_date, h.time)

                        t_str = dt_obj.strftime("%Y-%m-%dT%H:%M:00")
                        temp_c = float(h.temp) if h.temp is not None else 0.0
                        rain_mm = float(h.precipitation) if h.precipitation is not None else 0.0
                        wind_ms = float(h.wind_speed) if h.wind_speed is not None else 0.0

                        hourly_list.append({
                            'time': t_str,
                            'temp': temp_c,
                            'tempf': temp_c * 1.8 + 32.0,
                            'rainl': rain_mm,
                            'rains': 0.0,
                            'winds': wind_ms,
                            'windd': h.wind_direction if h.wind_direction is not None else 0,
                            'symb': h.condition if h.condition else 'd000',
                        })
                except Exception as e:
                    print(f"[Meteogram] Hourly fetch day {d} error: {e}")

            if hourly_list:
                now_str = datetime.datetime.now().strftime("%Y-%m-%dT%H:00:00")
                future_hours = [x for x in hourly_list if x['time'] >= now_str]
                if not future_hours:
                    future_hours = hourly_list

                if step == 3:
                    # Pick 3-hour rhythm: 02, 05, 08, 11, 14, 17, 20, 23
                    forecast = [
                        x for x in future_hours
                        if int(x['time'].split('T')[1][:2]) % 3 == 2
                    ]
                else:
                    forecast = future_hours

        town_val = place.name.strip()
        country_val = place.country_name.strip()
        translated_location = _translate_place(town_val, country_val)

        self["city_label"].setText(translated_location)

        # Set wind unit label
        if self.units:
            self["wind_unit_label"].setText(self.units.get_wind_label())
        else:
            self["wind_unit_label"].setText("km/h")

        # Draw all components
        self._draw_temperature_color(forecast, ranges)
        self._draw_rain(forecast, ranges)
        self._draw_hourly(forecast)
        self._draw_dates(forecast)

    def _draw_temperature_color(self, forecast, ranges):
        """
        Draws the temperature curve as coloured segments.
        Each segment's colour is based on the average temperature of its endpoints.
        Also draws the 0°C (or 32°F) line if the temperature range crosses zero.
        """
        unit_flag = 'c'
        if self.units:
            unit_flag = 'c' if self.units.get_simple_system() == 'metric' else 'f'

        temp_block = ranges.get('temp', {})
        if unit_flag == 'c':
            conf = temp_block.get(
                'metric', {
                    'start': -20, 'end': 40, 'step': 5})
        else:
            conf = temp_block.get('us', {'start': -4, 'end': 104, 'step': 9})

        tmin = conf['start']
        tmax = conf['end']
        tstep = conf['step']

        points = []
        x = 0
        for idx, item in enumerate(forecast):
            if idx >= PERIODS:
                break
            temp_val = item.get(
                'temp') if unit_flag == 'c' else item.get('tempf')
            if temp_val is None:
                temp_val = 0
            ratio = 1 - (temp_val - tmin) / (tmax - tmin)
            y = int(GRAPH_HEIGHT * ratio)
            points.append((x, y, temp_val))
            x += HOUR_STEP

        def temp_to_color(t):
            return get_color_from_celsius(t)

        segments = []
        for i in range(len(points) - 1):
            x1, y1, t1 = points[i]
            x2, y2, t2 = points[i + 1]
            avg_temp = (t1 + t2) / 2
            color = temp_to_color(avg_temp)
            segments.append(
                f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="3" />'
            )

        svg = f'''<?xml version="1.0" encoding="utf-8"?>
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
         width="{GRAPH_WIDTH}" height="{GRAPH_HEIGHT}"
         viewBox="0 0 {GRAPH_WIDTH} {GRAPH_HEIGHT}">
        {''.join(segments)}
    </svg>'''

        svg_file = join(METEOGRAM_DIR, 'foreca_temp_curve.svg')
        try:
            with open(svg_file, 'w') as f:
                f.write(svg)
            self["temp_curve"].instance.setPixmapFromFile(svg_file)
        except Exception as e:
            print(f"[Meteogram] Failed to write temperature SVG: {e}")

        # Left-hand temperature scale (8 labels)
        temps = []
        v = tmin
        while v <= tmax:
            temps.append(str(int(v)))
            v += tstep
        for i, txt in enumerate(temps[:8]):
            self[f"temp_scale_{i}"].setText(txt)
        self["temp_scale_0"].setText(("°C" if unit_flag == 'c' else "°F"))

        # -------------------------------------------------------------------------
        # Zero line (0°C / 32°F)
        # -------------------------------------------------------------------------
        zero_target = 0 if unit_flag == 'c' else 32
        if tmin < zero_target < tmax:
            fraction = (tmax - zero_target) / (tmax - tmin)
            zero_y = int(GRAPH_TOP + GRAPH_HEIGHT * fraction)

            zero_img = join(PLUGIN_PATH, "images", "zeroh.png")
            if exists(zero_img):
                self["zero_line"].instance.setPixmapFromFile(zero_img)
                current_pos = self["zero_line"].instance.position()
                self["zero_line"].move(ePoint(current_pos.x(), zero_y))
                self["zero_line"].show()
            else:
                self["zero_line"].hide()
        else:
            self["zero_line"].hide()

    def _draw_rain(self, forecast, ranges):
        rain_unit = 'mm'
        if self.units:
            rain_unit = self.units.get_precip_unit()

        rain_cfg = ranges.get('rain', {})
        if rain_unit == 'mm':
            rr = rain_cfg.get('metric', {'start': 0, 'end': 50, 'step': 5})
        else:
            rr = rain_cfg.get('us', {'start': 0, 'end': 2, 'step': 0.2})

        r0 = rr['start']
        r1 = rr['end']
        step = rr['step']
        span = r1 - r0
        if span <= 0:
            span = 1

        h = GRAPH_HEIGHT

        for n in range(PERIODS):
            if n >= len(forecast):
                self[f"rainbar_{n}"].hide()
                continue
            self[f"rainbar_{n}"].show()
            row = forecast[n]
            lx_mm = row.get('rainl', 0)
            s_mm = row.get('rains', 0)
            if rain_unit == 'mm':
                lx = lx_mm
                s = s_mm
            else:
                lx = lx_mm * 0.0393701
                s = s_mm * 0.0393701

            lh = int(h * lx / span)
            if lh < 0:
                lh = 0
            ly = h - lh
            sh = int(h * s / span)
            if sh < 0:
                sh = 0
            sy = ly - sh
            if sy < 0:
                sy = 0

            if DEBUG:
                print(
                    f"[Meteogram] Period {n}: lx={lx:.2f}, s={s:.2f}, lh={lh}, sh={sh}, ly={ly}, sy={sy}")

            if sh > 0:
                svg_chunk = f'''<?xml version="1.0" encoding="utf-8"?>
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="{h}">
      <rect x="0" y="{ly}" width="20" height="{lh}" fill="#1E90FF"/>
      <rect x="0" y="{sy}" width="20" height="{sh}" fill="#666666"/>
    </svg>'''
            else:
                svg_chunk = f'''<?xml version="1.0" encoding="utf-8"?>
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="{h}">
      <rect x="0" y="{ly}" width="20" height="{lh}" fill="#1E90FF"/>
    </svg>'''

            ftmp = join(METEOGRAM_DIR, f'rainbar_{n}.svg')
            try:
                with open(ftmp, 'w', encoding='utf-8') as f:
                    f.write(svg_chunk)
                self[f"rainbar_{n}"].instance.setPixmapFromFile(ftmp)
            except Exception as e:
                print(f"[Meteogram] Error rainbar {n}: {e}")

        values = []
        v = r0
        while v <= r1 + 0.001:
            values.append(v)
            v += step

        for i in range(min(8, len(values))):
            if rain_unit == 'mm':
                txt = str(int(values[i]))
            else:
                txt = f"{values[i]:.1f}"
            self[f"rain_scale_{i}"].setText(txt)

        self["rain_scale_0"].setText("mm" if rain_unit == 'mm' else "in")

    def _draw_hourly(self, forecast):
        """Fill hours, weather icons, wind directions and speeds."""
        for n in range(PERIODS):
            if n >= len(forecast):
                self[f"time_{n}"].setText(" ")
                self[f"windspeed_{n}"].setText(" ")
                self[f"weather_{n}"].hide()
                self[f"winddir_{n}"].hide()
                continue

            self[f"weather_{n}"].show()
            self[f"winddir_{n}"].show()
            row = forecast[n]

            # Time
            tval = row.get('time', '').split('T')[1][:5]
            self[f"time_{n}"].setText(tval)

            # Wind speed (original in m/s)
            ws_ms = row.get('winds', 0)
            if self.units:
                wind_val, _ = self.units.convert_wind(ws_ms)
                self[f"windspeed_{n}"].setText(str(int(wind_val)))
            else:
                self[f"windspeed_{n}"].setText(str(int(ws_ms * 3.6)))

            # Weather icon
            symb = row.get('symb', 'd000')
            fpath = get_icon_path(f"{symb}.png")
            if fpath:
                self[f"weather_{n}"].instance.setPixmapFromFile(fpath)
            else:
                fallback = get_icon_path("na.png")
                if fallback:
                    self[f"weather_{n}"].instance.setPixmapFromFile(fallback)
                else:
                    self[f"weather_{n}"].hide()

            # Wind direction icon
            deg = row.get('windd', 0)
            card = wind_arrow(deg)
            wfile = get_icon_path(f"w{card}.png")
            if wfile:
                self[f"winddir_{n}"].instance.setPixmapFromFile(wfile)
            else:
                fallback = get_icon_path("wN.png")
                if fallback:
                    self[f"winddir_{n}"].instance.setPixmapFromFile(fallback)

    def _draw_dates(self, forecast):
        """Add date labels and vertical lines aligned to 02:00 (up to 10 days)."""
        cur_day = None
        start_idx = 0
        blocks = []

        for i, r in enumerate(forecast[:PERIODS]):
            dstr = r.get('time', '').split('T')[0]
            if dstr != cur_day:
                if cur_day is not None:
                    blocks.append((cur_day, start_idx))
                cur_day = dstr
                start_idx = i
        if cur_day:
            blocks.append((cur_day, start_idx))

        grid_start_x = 120
        sep_img = join(PLUGIN_PATH, "images", "sep.png")

        for idx in range(9):
            if idx < len(blocks):
                ds, pos = blocks[idx]
                line_x = grid_start_x + (pos * HOUR_STEP) - 1

                # Siirrä päivämääräotsikko pystyviivan oikealle puolelle
                date_y = self[f"date_{idx}"].instance.position().y()
                self[f"date_{idx}"].move(ePoint(line_x + 6, date_y))

                if idx == 0 and len(blocks) > 1 and blocks[1][1] <= 2:
                    if blocks[1][1] == 1:
                        # Vain 1 sarake jäljellä -> piilota teksti
                        self[f"date_{idx}"].setText("")
                    else:
                        # 2 saraketta jäljellä -> siirrä vasemmalle (x = 65)
                        self[f"date_{idx}"].move(ePoint(65, date_y))
                        try:
                            dt = datetime.datetime.strptime(ds, "%Y-%m-%d")
                            self[f"date_{idx}"].setText(dt.strftime("%a, %d.%m"))
                        except BaseException:
                            self[f"date_{idx}"].setText(ds)
                else:
                    try:
                        dt = datetime.datetime.strptime(ds, "%Y-%m-%d")
                        self[f"date_{idx}"].setText(dt.strftime("%a, %d.%m"))
                    except BaseException:
                        self[f"date_{idx}"].setText(ds)
                self[f"date_{idx}"].show()

                # Piirrä ja siirrä pystyviiva (ohitetaan aivan vasen reuna pos == 0)
                if pos > 0:
                    vline_y = self[f"vline_{idx}"].instance.position().y()
                    self[f"vline_{idx}"].move(ePoint(line_x, vline_y))
                    if exists(sep_img):
                        self[f"vline_{idx}"].instance.setPixmapFromFile(sep_img)
                    self[f"vline_{idx}"].show()
                else:
                    self[f"vline_{idx}"].hide()
            else:
                self[f"date_{idx}"].setText("")
                self[f"vline_{idx}"].hide()

    def open_settings_menu(self):
        choices = [
            (_("Time step: 1 hour (1h)"), "1"),
            (_("Time step: 3 hours (3h)"), "3"),
            (_("Time step: 6 hours (6h)"), "6"),
        ]
        current = config.plugins.foreca1.meteogram_step.value
        selected_idx = next((i for i, c in enumerate(choices) if c[1] == current), 2)

        self.session.openWithCallback(
            self.settings_callback,
            ChoiceBox,
            title=_("Meteogram Settings"),
            list=choices,
            selection=selected_idx
        )

    def settings_callback(self, choice):
        if choice is not None:
            config.plugins.foreca1.meteogram_step.value = choice[1]
            config.plugins.foreca1.meteogram_step.save()
            configfile.save()
            self.fetch_data()
